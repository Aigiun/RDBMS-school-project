-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema IS680Team2DoorDashFinal
-- -----------------------------------------------------
-- This is the live DB for our team project. Billy, Aigiun, Veronica and Kingshok. Until further notice…

-- -----------------------------------------------------
-- Schema IS680Team2DoorDashFinal
--
-- This is the live DB for our team project. Billy, Aigiun, Veronica and Kingshok. Until further notice…
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `IS680Team2DoorDashFinal` DEFAULT CHARACTER SET utf8 ;
USE `IS680Team2DoorDashFinal` ;

-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`Orders`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`Orders` (
  `idOrders` INT NOT NULL,
  `idOrderLine` INT NOT NULL,
  `idDeliveries` INT NULL,
  `idOrderStatus` INT NOT NULL,
  `orderDateTime` DATETIME NOT NULL,
  `idCustomer` VARCHAR(45) NULL,
  `idPayment` INT NULL DEFAULT 6,
  PRIMARY KEY (`idOrders`),
  UNIQUE INDEX `idOrders_UNIQUE` (`idOrders` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`OrderLine`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`OrderLine` (
  `idMenuItem` INT NOT NULL,
  `quantity` INT NOT NULL,
  `idOrderLine` INT NOT NULL,
  PRIMARY KEY (`idOrderLine`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`Restaurant`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`Restaurant` (
  `restaurantName` VARCHAR(45) NOT NULL,
  `restaurantStreet` VARCHAR(45) NOT NULL,
  `restaurantOpen` DATETIME NOT NULL,
  `restaurantClose` DATETIME NOT NULL,
  `restaurantPhone` VARCHAR(45) NOT NULL,
  `restaurantZIP` CHAR(5) NOT NULL,
  `idRestaurantImages` INT NULL,
  `idRestaurant` INT NOT NULL,
  `idMenu` INT NOT NULL,
  PRIMARY KEY (`idRestaurant`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`MenuItem`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`MenuItem` (
  `idMenuItems` INT NOT NULL,
  `idRestaurant` VARCHAR(45) NULL,
  `menuItemName` VARCHAR(45) NULL,
  `idMenuImages` INT NULL,
  `menuItemsDescription` VARCHAR(45) NULL,
  `menuItemVegetarian` VARCHAR(1) NULL,
  `menuItemVegan` VARCHAR(1) NULL,
  `menuItemGlutenFree` VARCHAR(1) NULL,
  `menuItemDairyFree` VARCHAR(1) NULL,
  `menuItemPrice` DECIMAL(3,2) NOT NULL,
  PRIMARY KEY (`idMenuItems`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`review`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`review` (
  `idReview` INT NOT NULL,
  `idCustomer` INT NOT NULL,
  `reviewText` VARCHAR(45) NULL,
  `reviewImage` VARCHAR(45) NULL,
  `reviewRating` VARCHAR(45) NULL,
  PRIMARY KEY (`idReview`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`reviewImages`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`reviewImages` (
  `idReviewImages` INT NOT NULL,
  `reviewImagesImage` VARCHAR(45) BINARY NOT NULL,
  `reviewImagesDescription` VARCHAR(45) NULL)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`MenuImages`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`MenuImages` (
  `idMenuImages` INT NOT NULL,
  `menuImagesImage` VARCHAR(45) BINARY NOT NULL,
  `menuImagesDescription` VARCHAR(45) NULL,
  PRIMARY KEY (`idMenuImages`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`Menu`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`Menu` (
  `idMenu` INT NOT NULL,
  `menuType` VARCHAR(45) NULL,
  `menuAvailable` DATETIME NOT NULL,
  `idMenuItem` INT NOT NULL,
  `idRestaurant` INT NOT NULL,
  PRIMARY KEY (`idMenu`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`OrderStatus`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`OrderStatus` (
  `idOrderStatusCatalog` INT NOT NULL,
  `orderStatusDate` DATETIME NOT NULL,
  `idOrderStatus` INT NOT NULL,
  PRIMARY KEY (`idOrderStatus`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`OrderStatusCatalog`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`OrderStatusCatalog` (
  `idOrderStatusCatalog` INT NOT NULL,
  `OrderStatusCatalogStatus` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`idOrderStatusCatalog`),
  UNIQUE INDEX `OrderStatusCatalogStatus_UNIQUE` (`OrderStatusCatalogStatus` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`Customers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`Customers` (
  `idCustomer` INT NOT NULL,
  `customerName` VARCHAR(45) NOT NULL,
  `customerStreet` VARCHAR(45) NOT NULL,
  `customerZip` CHAR(5) NOT NULL,
  `customerApartment` VARCHAR(5) NULL,
  `customerPhone` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`idCustomer`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`RestaurantImages`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`RestaurantImages` (
  `idRestaurantImages` INT NOT NULL,
  `restaurantImage` VARCHAR(45) BINARY NOT NULL,
  `restaurantImageDescription` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idRestaurantImages`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`Deliveries`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`Deliveries` (
  `idDeliveries` INT NOT NULL,
  `idDasher` INT NOT NULL,
  `deliverySpecialInstructions` VARCHAR(140) NULL,
  `idDeliveryStatus` INT NULL,
  PRIMARY KEY (`idDeliveries`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`DeliveryStatus`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`DeliveryStatus` (
  `idDeliveryStatus` INT NOT NULL,
  `deliveryStatusTime` DATETIME NOT NULL,
  `deliveryStatus` BIT(1) NOT NULL,
  `deliveryStatusComments` VARCHAR(140) NULL,
  `idDeliveryStatusIssues` INT NULL,
  PRIMARY KEY (`idDeliveryStatus`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`Dasher`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`Dasher` (
  `idDasher` INT NOT NULL,
  `dasherName` VARCHAR(45) NULL,
  `dasherRating` DECIMAL(1,1) NULL,
  `dasherStreet` VARCHAR(45) NULL,
  `dasherCity` VARCHAR(45) NULL,
  `DasherState` CHAR(2) NULL,
  `dasherZIP` CHAR(5) NULL,
  `dasherPhone` VARCHAR(20) NULL,
  `dasherDriverLicense` VARCHAR(15) NULL,
  PRIMARY KEY (`idDasher`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`DeliveryStatusIssues`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`DeliveryStatusIssues` (
  `idDeliveryStatusIssues` INT NOT NULL,
  `deliveryStatusIssue` VARCHAR(45) NULL,
  PRIMARY KEY (`idDeliveryStatusIssues`),
  UNIQUE INDEX `deliveryStatusIssue_UNIQUE` (`deliveryStatusIssue` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`Payment`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`Payment` (
  `idPayment` INT NOT NULL,
  `paymentAmount` DECIMAL(5,2) NULL,
  `paymentTime` DATETIME NULL,
  `idPaymentMethod` INT NULL,
  `idPaymentType` INT NULL,
  PRIMARY KEY (`idPayment`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`PaymentType`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`PaymentType` (
  `idPaymentType` INT NOT NULL,
  `paymentType` BIT(1) NULL,
  PRIMARY KEY (`idPaymentType`),
  UNIQUE INDEX `paymentType_UNIQUE` (`paymentType` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IS680Team2DoorDashFinal`.`PaymentMethod`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IS680Team2DoorDashFinal`.`PaymentMethod` (
  `idPaymentMethod` INT NOT NULL,
  `paymentMethod` VARCHAR(45) NULL,
  `paymentCardNumber` VARCHAR(45) NULL,
  `paymenCardExpiration` DATETIME NULL,
  `paymentCardCVC` VARCHAR(4) NULL,
  `paymentCardZIP` CHAR(5) NULL,
  `paymentCardNameOnCard` VARCHAR(45) NULL,
  PRIMARY KEY (`idPaymentMethod`))
ENGINE = InnoDB;

CREATE USER 'user1';


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
