SELECT
Customers.idCustomer,
Customers.CustomerName,
Customers.customerZip,
Review.idReview,
Review.reviewText

FROM Customers
INNER JOIN Review on Review.idCustomer = Review.idCustomer

;