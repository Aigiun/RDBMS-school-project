SELECT 
Restaurant.idRestaurant,
Restaurant.restaurantName,
avg(MenuItem.menuItemPrice)

FROM MenuItem 

INNER JOIN Restaurant ON Restaurant.idRestaurant = MenuItem.idRestaurant

group by Restaurant.idRestaurant


;