SELECT *
FROM Dasher
WHERE Dasher.dasherRating >= 3.0
;