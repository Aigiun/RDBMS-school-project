SELECT 
OrderLine.idOrders,
OrderLine.idOrderLine,
OrderLine.idMenuItem,
MenuItem.menuItemName,
MenuItem.menuItemPrice,
OrderLine.quantity,
sum(menuItemPrice*quantity)

FROM OrderLine
INNER JOIN MenuItem on MenuItem.idMenuItems = OrderLine.idMenuItem
group by OrderLine.idOrders


;