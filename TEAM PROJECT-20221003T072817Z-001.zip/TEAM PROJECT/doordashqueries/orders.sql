SELECT 
OrderLine.idOrders,
OrderLine.idOrderLine,
OrderLine.idMenuItem,
MenuItem.menuItemName

FROM OrderLine
INNER JOIN MenuItem on MenuItem.idMenuItems = OrderLine.idMenuItem



;