SELECT 
Restaurant.idRestaurant,
Restaurant.restaurantName,
MenuItem.menuItemName,
MenuItem.menuItemVegan,
MenuItem.menuItemPrice

FROM MenuItem 

INNER JOIN Restaurant ON Restaurant.idRestaurant = MenuItem.idRestaurant

WHERE menuItemVegetarian = 'Y'
;